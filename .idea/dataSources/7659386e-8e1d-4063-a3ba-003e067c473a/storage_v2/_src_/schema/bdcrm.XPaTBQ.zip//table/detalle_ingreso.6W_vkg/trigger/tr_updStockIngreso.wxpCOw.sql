create trigger tr_updStockIngreso
  after INSERT
  on detalle_ingreso
  for each row
BEGIN
 UPDATE articulo SET stock = stock + NEW.cantidad 
 WHERE articulo.idarticulo = NEW.idarticulo;
END;

